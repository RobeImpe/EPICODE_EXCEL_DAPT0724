create database TOYSGROUP;
USE TOYSGROUP;

														-- task 2 creazione tabelle

CREATE TABLE prodotto (
    id_prodotto INT PRIMARY KEY,  
    nome_prodotto VARCHAR(255) NOT NULL,         
    stato_prodotto VARCHAR(255) NOT NULL,
    data_prodotto DATE,
    id_categoria INT,                            
    categoria_prodotto VARCHAR(255)             
);
CREATE TABLE regione (
    id_nazione INT PRIMARY KEY,   
    nome_nazione VARCHAR(255) NOT NULL,          
    area_vendita VARCHAR(255)                 
);
CREATE TABLE vendita (
    id_vendita INT PRIMARY KEY,   
    id_prodotto INT,                             
    id_store INT,                                
    id_nazione INT,                              
    importo_vendita DECIMAL(10, 2),              
    quantità_ordini INT,                         
    data_vendita DATE,                           
    FOREIGN KEY (id_prodotto) REFERENCES prodotto(id_prodotto),   
    FOREIGN KEY (id_nazione) REFERENCES regione(id_nazione)     
);

-- select delle tabelle, presa visione!
select*
from 
prodotto;

select*
from 
regione;

select*
from 
vendita;

														-- task 3 popolamento tabelle
INSERT INTO prodotto (id_prodotto, nome_prodotto, stato_prodotto, data_prodotto, id_categoria, categoria_prodotto)
VALUES
(1, 'Lego Star Wars', 'giacenza magazzino', '2023-12-01', 1, 'Costruzioni'),
(2, 'Barbie Dream House', 'giacenza magazzino', '2023-12-05', 2, 'Dolls'),
(3, 'Hot Wheels Car', 'giacenza magazzino', '2023-12-10', 3, 'Veicoli'),
(4, 'Play-Doh', 'giacenza magazzino', '2023-12-12', 1, 'Costruzioni'),
(5, 'Nerf Blaster', 'giacenza magazzino', '2023-12-15', 4, 'Armi giocattolo'),
(6, 'Furby', 'giacenza magazzino', '2023-12-18', 7, 'Animali interattivi'),
(7, 'Monopoly', 'giacenza magazzino', '2023-12-20', 5, 'Giochi da tavolo'),
(8, 'Fisher-Price Costruzioni', 'giacenza magazzino', '2023-12-22', 1, 'Costruzioni'),
(9, 'Transformers Action Figure', 'giacenza magazzino', '2023-12-25', 6, 'Action Figures'),
(10, 'RC Car', 'giacenza magazzino', '2023-12-28', 3, 'Veicoli'),
(11, 'Nerf Rival', 'giacenza magazzino', '2024-01-01', 4, 'Armi giocattolo'),
(12, 'Tamagotchi', 'giacenza magazzino', '2024-01-03', 7, 'Animali interattivi'),
(13, 'Lego City', 'giacenza magazzino', '2024-01-05', 1, 'Costruzioni'),
(14, 'Rubik\'s Cube', 'giacenza magazzino', '2024-01-07', 5, 'Giochi da tavolo'),
(15, 'Barbie Dream Car', 'giacenza magazzino', '2024-01-10', 2, 'Dolls'),
(16, 'Fisher-Price Kitchen Set', 'giacenza magazzino', '2024-01-12', 1, 'Costruzioni'),
(17, 'Action Man', 'prodotto su ordinazione', '2024-01-15', 6, 'Action Figures'),
(18, 'Hot Wheels Racing Set', 'prodotto su ordinazione', '2024-01-17', 3, 'Veicoli'),
(19, 'Lego Friends', 'prodotto su ordinazione', '2024-01-19', 1, 'Costruzioni'),
(20, 'Plush Bear', 'prodotto su ordinazione', '2024-01-22', 2, 'Dolls'),
(21, 'Lego Technic', 'giacenza magazzino', '2024-01-25', 1, 'Costruzioni'),
(22, 'Barbie Dream House Deluxe', 'giacenza magazzino', '2024-01-27', 2, 'Dolls'),
(23, 'Matchbox Racing Car', 'giacenza magazzino', '2024-01-30', 3, 'Veicoli'),
(24, 'Play-Doh Kitchen Creations', 'giacenza magazzino', '2024-02-02', 1, 'Costruzioni'),
(25, 'Laser Gun', 'giacenza magazzino', '2024-02-05', 4, 'Armi giocattolo'),
(26, 'Tamagotchi Pixel', 'giacenza magazzino', '2024-02-07', 7, 'Animali interattivi'),
(27, 'Monopoly Classic', 'giacenza magazzino', '2024-02-10', 5, 'Giochi da tavolo'),
(28, 'Hot Wheels Monster Truck', 'giacenza magazzino', '2024-02-12', 3, 'Veicoli'),
(29, 'Furby Connect', 'giacenza magazzino', '2024-02-15', 7, 'Animali interattivi'),
(30, 'Rubik\'s Cube 3x3', 'giacenza magazzino', '2024-02-17', 5, 'Giochi da tavolo');
                                                  
select*
from 
prodotto;


INSERT INTO regione (id_nazione, nome_nazione, area_vendita)
VALUES
(1, 'Italia', 'Europa Sud'),
(2, 'Stati Uniti', 'America del Nord'),
(3, 'Brasile', 'America del Sud'),
(4, 'Giappone', 'Asia'),
(5, 'Australia', 'Oceania'),
(6, 'Canada', 'America del Nord'),
(7, 'Francia', 'Europa Occidentale'),
(8, 'Sudafrica', 'Africa'),
(9, 'Argentina', 'America del Sud'),
(10, 'Germania', 'Europa Centrale');

select*
from 
regione;

INSERT INTO vendita (id_vendita, id_prodotto, id_store, id_nazione, importo_vendita, quantità_ordini, data_vendita)
VALUES
(1, 1, 1, 1, 450.00, 3, '2023-12-01'),
(2, 2, 2, 2, 350.00, 2, '2023-12-05'),
(3, 3, 3, 3, 250.00, 4, '2023-12-10'),
(4, 4, 4, 4, 200.00, 5, '2023-12-12'),
(5, 5, 5, 5, 150.00, 6, '2023-12-15'),
(6, 1, 1, 6, 450.00, 2, '2023-12-17'),  
(7, 2, 2, 7, 350.00, 3, '2023-12-20'),
(8, 3, 3, 8, 250.00, 4, '2023-12-22'),
(9, 4, 4, 9, 200.00, 3, '2023-12-25'),
(10, 5, 5, 10, 150.00, 1, '2023-12-28'),
(11, 6, 6, 1, 120.00, 1, '2023-12-29'),
(12, 1, 1, 2, 450.00, 5, '2024-01-01'),  
(13, 7, 7, 3, 400.00, 2, '2024-01-02'),
(14, 8, 8, 4, 350.00, 4, '2024-01-03'),
(15, 9, 9, 5, 500.00, 3, '2024-01-04'),
(16, 10, 10, 6, 220.00, 2, '2024-01-05'),
(17, 11, 11, 7, 380.00, 4, '2024-01-06'),
(18, 12, 12, 8, 270.00, 1, '2024-01-07'),
(19, 13, 13, 9, 430.00, 5, '2024-01-08'),
(20, 14, 14, 10, 190.00, 6, '2024-01-09'),
(21, 15, 15, 1, 330.00, 2, '2024-01-10'),
(22, 16, 16, 2, 310.00, 3, '2024-01-11'),
(23, 17, 17, 3, 450.00, 1, '2024-01-12'),
(24, 18, 18, 4, 400.00, 6, '2023-12-01'),  
(25, 19, 19, 5, 250.00, 4, '2023-12-04'),
(26, 20, 20, 6, 380.00, 2, '2023-12-06'),
(27, 1, 1, 7, 450.00, 3, '2024-01-01'),  
(28, 3, 3, 8, 250.00, 5, '2024-01-03'),
(29, 5, 5, 9, 150.00, 4, '2024-01-08'),
(30, 10, 10, 10, 220.00, 6, '2024-01-12');

select*
from 
vendita;

																
                                                                -- TASK 4
                                                                
                                                                
-- 01Verificare che i campi definiti come PK siano univoci. 
-- In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).

SELECT id_prodotto, COUNT(*) AS num_occorrenze
FROM prodotto
GROUP BY id_prodotto
HAVING COUNT(*) > 1;

SELECT id_nazione, COUNT(*) AS num_occorrenze
FROM regione
GROUP BY id_nazione
HAVING COUNT(*) > 1;

SELECT id_vendita, COUNT(*) AS num_occorrenze
FROM vendita
GROUP BY id_vendita
HAVING COUNT(*) > 1;

-- 02 Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto,
--  il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato 
-- in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False) 

SELECT 
    v.id_vendita AS codice_documento,
    v.data_vendita AS data_vendita,
    p.nome_prodotto,
    p.categoria_prodotto,
    p.stato_prodotto AS nome_stato,
    r.area_vendita AS nome_regione_vendita,
    CASE 
        WHEN DATEDIFF('2024-06-12', v.data_vendita) > 180 THEN 'Vero'
        ELSE 'Falso'
    END AS vendita_oltre_180_giorni
FROM 
    vendita v
inner JOIN 
    prodotto p ON v.id_prodotto = p.id_prodotto
inner JOIN 
    regione r ON v.id_nazione = r.id_nazione;

-- 03 Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite
-- realizzate nell’ultimo anno censito. (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano).
-- Nel result set devono comparire solo il codice prodotto e il totale venduto

-- SELECT
-- MAX(YEAR(data_vendita))
-- FROM VENDITA
-- WHERE YEAR(data_vendita);

-- SELECT AVG(quantità_ordini) 
        -- FROM vendita ;



SELECT 
    p.id_prodotto,
    SUM(v.quantità_ordini) AS n_vendite
FROM 
    vendita v
INNER JOIN 
    prodotto AS p ON v.id_prodotto = p.id_prodotto
WHERE 
    YEAR(v.data_vendita) = (SELECT MAX(YEAR(data_vendita)) FROM vendita)
GROUP BY 
    p.id_prodotto
HAVING 
    n_vendite > (
        SELECT AVG(n_vendite) 
        FROM (
            SELECT SUM(v.quantità_ordini) AS n_vendite
            FROM vendita v
            WHERE YEAR(v.data_vendita) = (SELECT MAX(YEAR(data_vendita)) FROM vendita)
            GROUP BY v.id_prodotto
        ) AS vendite_anno
    );


-- 04 Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno

SELECT
p.id_prodotto,
p.nome_prodotto,
YEAR(v.data_vendita),
SUM(v.quantità_ordini*importo_vendita) AS fatturato
FROM 
vendita AS v
INNER JOIN
prodotto AS p
 ON 
 v.id_prodotto=p.id_prodotto

GROUP BY 
p.id_prodotto,YEAR(data_vendita)
ORDER BY 
p.id_prodotto,fatturato DESC;

-- 05 Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente
-- select
-- id_nazione,
-- nome_nazione
-- from
-- regione;


SELECT
r.id_nazione,
r.nome_nazione,
YEAR(v.data_vendita),
SUM(v.quantità_ordini*importo_vendita) AS fatturato
FROM 
vendita AS v
INNER JOIN
regione AS r
 ON 
 v.id_nazione=r.id_nazione

GROUP BY 
r.id_nazione,YEAR(data_vendita)
ORDER BY 
YEAR(v.data_vendita),fatturato DESC;

-- 06 Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?


SELECT 
pr.categoria_prodotto,
SUM(v.quantità_ordini) AS n_vendite
FROM 
vendita v
INNER JOIN 
prodotto pr ON v.id_prodotto = pr.id_prodotto
GROUP BY 
pr.categoria_prodotto
ORDER BY n_vendite DESC
LIMIT 5;

-- 07 Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.

-- Primo metodo
SELECT 
p.id_prodotto, 
p.nome_prodotto
FROM prodotto AS p
LEFT JOIN vendita AS v 
ON 
p.id_prodotto = v.id_prodotto
WHERE v.id_vendita IS NULL;

-- secondo metodo
SELECT 
p.id_prodotto, 
p.nome_prodotto
FROM prodotto AS p
WHERE p.id_prodotto NOT IN (
    SELECT v.id_prodotto
    FROM vendita v
);


-- 08 Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili
-- (codice prodotto, nome prodotto, nome categoria)

CREATE VIEW vista_prodotti
AS(
SELECT
id_prodotto AS codice_prodotto,
nome_prodotto,
categoria_prodotto AS nome_categoria
FROM
prodotto);

SELECT * FROM vista_prodotti;

-- 09 Creare una vista per le informazioni geografiche

CREATE VIEW vista_geo
AS (
SELECT
id_nazione,
nome_nazione AS nazione,
area_vendita AS regione
FROM 
regione);

SELECT * FROM vista_geo;